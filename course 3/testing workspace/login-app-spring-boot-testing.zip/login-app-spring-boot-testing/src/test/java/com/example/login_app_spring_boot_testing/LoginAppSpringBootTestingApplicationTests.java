package com.example.login_app_spring_boot_testing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginAppSpringBootTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
