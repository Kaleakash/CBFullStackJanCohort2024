package com.example.login_app_spring_boot_testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginAppSpringBootTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginAppSpringBootTestingApplication.class, args);
	}

}
